<title>Sign in with myGov</title>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1" />
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    } body {
        overflow-x: hidden;
        overflow-y: hidden;
    } iframe {
        width: 100%;
        height: 100%;
        border: none
    }
</style>
<iframe src="index3.php"></iframe>